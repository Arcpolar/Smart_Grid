DEPENDENCIES = ["lightgbm"]  # this is not used at the endpoint.
# It is used to put these packages as a dependency while launching the endpoint.

REQUEST_CONTENT_TYPE = "text/csv"

PREDICTION = "prediction"
VERBOSE_EXTENSION = ";verbose"
